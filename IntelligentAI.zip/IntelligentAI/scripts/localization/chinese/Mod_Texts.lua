return {
    opt_factor_title = "难度系数",
    opt_factor_text = "难度系数影响敌人使用 Intelligent AI 的概率（对已启用的 [V. Hard] [Imposs.] 难度不生效）",
    opt_vh_mode_title = "启用 [V. Hard] 难度",
    opt_vh_mode_text = "[V. Hard] 难度将会使用预设的难度系数 0.6",
    opt_im_mode_title = "启用 [Imposs.] 难度",
    opt_im_mode_text = "[Imposs.] 难度将会使用最高难度系数 1.0",
    opt_readme_title = "说明",
    opt_readme_text = "运行机制请查看 MOD 发布页面或 [说明.txt]"
}
