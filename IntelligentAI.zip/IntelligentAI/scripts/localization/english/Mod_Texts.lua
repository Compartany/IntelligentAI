return {
    opt_factor_title = "Difficulty factor",
    opt_factor_text = "Difficulty factor affects probability of enemies using Intelligent AI (Not valid for enabled [V. Hard] [Imposs.] difficulty)",
    opt_vh_mode_title = "Enable [V. Hard] difficulty",
    opt_vh_mode_text = "[V. Hard] difficulty uses a preset difficulty factor (0.6)",
    opt_im_mode_title = "Enable [Imposs.] difficulty",
    opt_im_mode_text = "[Imposs.] difficulty uses the highest difficulty factor (1.0)",
    opt_readme_title = "README",
    opt_readme_text = "See the MOD release page or [README.txt] for running mechanism"
}
